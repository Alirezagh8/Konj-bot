import telebot
import os

API_TOKEN = os.getenv('API_TOKEN')
ADMIN_ID = int(os.getenv('ADMIN_ID'))

bot = telebot.TeleBot(API_TOKEN)
last_sender = {}

@bot.message_handler(func=lambda message: True)
def forward_message(message):
    user_id = message.from_user.id
    full_text = f"پیام از @{message.from_user.username or 'ناشناس'}:\n\n{message.text}"
    last_sender[ADMIN_ID] = user_id
    bot.send_message(ADMIN_ID, full_text)

@bot.message_handler(func=lambda message: message.chat.id == ADMIN_ID and message.reply_to_message)
def reply_to_user(message):
    user_id = last_sender.get(ADMIN_ID)
    if user_id:
        bot.send_message(user_id, message.text)
    else:
        bot.send_message(ADMIN_ID, "نمی‌دونم به کی باید جواب بدم!")

bot.polling()
